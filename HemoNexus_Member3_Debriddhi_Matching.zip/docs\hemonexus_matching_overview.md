# 🩸 HemoNexus — Matching Algorithm Overview

> **Status: ✅ 58/58 tests passing** | Python 3.13 · Flask 3.x · SQLite · pytest

---

## Architecture at a Glance

```mermaid
flowchart TD
    A["Patient Blood Request\n(blood group, location, urgency, time)"] --> B["Step 1: Blood Group Filter\nfilter_by_blood_group()"]
    B --> C["Step 2: Active Profile Check\nfilter_by_active_status()"]
    C --> D["Step 3: 6-Month Verification Check\nfilter_by_verification_status()"]
    D --> E["Step 4: Temporary Availability\nfilter_by_temporary_availability()"]
    E --> F["Step 5: Schedule Window Check\nfilter_by_availability_schedule()"]
    F --> G["Step 6: Haversine Distance\ncalculate_and_attach_distances()"]
    G --> H["Step 7: Patient Radius Filter\nfilter_by_patient_distance()"]
    H --> I["Step 8: Donor Travel Limit\nfilter_by_donor_travel_limit()"]
    I --> J["Step 9: Ranking\napply_ranking()"]
    J --> K["Step 10: Privacy Sanitization\nFinal Results + Medical Disclaimer"]
```

---

## Module Map

| File | Role |
|---|---|
| [`matching/matcher.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/matching/matcher.py) | **Pipeline orchestrator** — `run_matching_pipeline()` and `find_matching_donors()` |
| [`matching/filters.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/matching/filters.py) | All 8 filter functions (steps 1–8) |
| [`matching/ranking.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/matching/ranking.py) | 4 ranking modes + composite score calculator |
| [`matching/distance.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/matching/distance.py) | Haversine formula + travel time estimation |
| [`matching/availability.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/matching/availability.py) | Time-window availability engine (handles midnight crossing) |
| [`backend/services/matching_service.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/backend/services/matching_service.py) | Bridge adapter for backward-compatible API imports |

---

## The 10-Step Pipeline

### Steps 1–8: Filters (Prune Phase)
> [!IMPORTANT] Filters are **absolute gates** — a donor that fails any step is permanently excluded. Ranking cannot resurrect them.

| Step | Filter | Logic |
|---|---|---|
| 1 | **Blood Group** | Exact ABO/Rh match (e.g. O+ donor for O+ request) |
| 2 | **Active Status** | `profile_status == 'ACTIVE'` only (`VERIFICATION_DUE` / `INACTIVE` excluded) |
| 3 | **6-Month Verification** | `next_verification_date` must not have lapsed (30-day grace period allowed) |
| 4 | **Temporary Availability** | `is_available == 1` (donor's own toggle) |
| 5 | **Availability Schedule** | Request time must fall inside donor's declared window |
| 6 | **Haversine Distance** | Great-circle distance attached to each candidate |
| 7 | **Patient Radius** | `distance_km ≤ preferred_max_distance` (default 25 km) |
| 8 | **Donor Travel Limit** | `distance_km ≤ donor.maximum_travel_distance` (default 15 km) |

### Step 9: Ranking (Sort Phase)
Four selectable sorting modes:

| Mode | Key | Logic |
|---|---|---|
| `NEAREST` | `distance_km ↑` | Closest donor first |
| `FASTEST` | `estimated_travel_time ↑` | Shortest estimated drive time |
| `RECENTLY_VERIFIED` | `last_verified_date ↓` | Freshest profile first |
| `BEST_MATCH` | `matching_score ↓` | Composite weighted score (default) |

### Composite Score Formula (BEST_MATCH)

$$\text{Score} = \left(0.30 \times S_{\text{avail}}\right) + \left(0.30 \times S_{\text{dist}} \times U\right) + \left(0.20 \times S_{\text{fresh}}\right) + \left(0.20 \times S_{\text{prox}}\right)$$

| Factor | Weight | Range | Description |
|---|---|---|---|
| $S_{\text{avail}}$ | 30% | 0.7 – 1.0 | Availability suitability score |
| $S_{\text{dist}}$ | 30% | 0.0 – 1.0 | Proximity (1 = at same location) |
| $S_{\text{fresh}}$ | 20% | 0.1 – 1.0 | Verification recency (decays linearly over 180 days) |
| $S_{\text{prox}}$ | 20% | 0.0 – 1.0 | Proximity fit bonus |
| $U$ | modifier | 1.0 / 1.1 / 1.2 | Urgency multiplier (NORMAL / URGENT / CRITICAL) |

### Step 10: Privacy Sanitization
- Exact GPS coordinates **masked** from response
- Contact details gated behind explicit dispatch workflow
- Medical safety disclaimer appended to every result

---

## Availability Schedules

| Type | Window | Suitability Score | Midnight Crossing? |
|---|---|---|---|
| `24_HOURS` | Always | 1.0 | — |
| `DAYTIME` | 08:00–18:00 | 0.9 | No |
| `NIGHTTIME` | 18:00–06:00 | 0.9 | ✅ Yes |
| `8_HOURS` | 09:00–17:00 | 0.85 | No |
| Custom | `available_from`–`available_to` | 0.85 | ✅ If crossing midnight |

> [!TIP] The `is_time_in_range()` function in [`availability.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/matching/availability.py#L23-L42) correctly handles overnight intervals (e.g. 22:00–04:00) by checking `current >= start OR current < end`.

---

## Donor Verification Lifecycle

```mermaid
stateDiagram-v2
    [*] --> ACTIVE: Registration / Self-Confirmation
    ACTIVE --> VERIFICATION_DUE: 180 days elapsed
    VERIFICATION_DUE --> ACTIVE: Donor self-confirms
    VERIFICATION_DUE --> INACTIVE: 30-day grace period expired
    INACTIVE --> ACTIVE: Admin override or re-verification
    INACTIVE --> [*]: Profile retained but excluded from matching
```

---

## Key Configurable Parameters ([`config.py`](file:///C:/Users/DEBSRIDDHI%20GHOSH/Documents/GitHub/HemoNexus/config.py))

| Setting | Default | Description |
|---|---|---|
| `VERIFICATION_INTERVAL_DAYS` | 180 | Verification cycle length |
| `GRACE_PERIOD_DAYS` | 30 | Days after due date before INACTIVE |
| `DEFAULT_MAX_DISTANCE_KM` | 25.0 km | Patient search radius |
| `DEFAULT_AVERAGE_SPEED_KMH` | 30.0 km/h | Urban travel speed estimate |
| `WEIGHT_AVAILABILITY` | 0.30 | Score weight |
| `WEIGHT_DISTANCE` | 0.30 | Score weight |
| `WEIGHT_FRESHNESS` | 0.20 | Score weight |
| `WEIGHT_PROXIMITY_FIT` | 0.20 | Score weight |

---

## Test Coverage

```
tests/test_20_requirements.py   20 cases — all filter + ranking permutations
tests/test_matching.py           4 cases — Haversine, availability, recency, full pipeline
tests/test_donor.py              7 cases — profile CRUD, verification lifecycle
tests/test_requests.py           4 cases — create, dispatch, accept, cancel
tests/test_auth.py               9 cases — register, login, session, logout
tests/test_admin.py              7 cases — RBAC, stats, sweep, override
tests/test_security.py           4 cases — SQL injection, password protection, isolation
─────────────────────────────────────────────────────────
Total: 58 passed ✅ (0 failed, 0 skipped)
```

---

## Possible Enhancements

| Enhancement | Description |
|---|---|
| **Blood group compatibility matrix** | Allow universal donors (O-) to match non-exact requests |
| **Donation cooldown filter** | Exclude donors who donated within the last 90 days |
| **Rating/feedback score** | Weight donors who've completed past donations higher |
| **Real-time notifications** | WebSocket push to donors when dispatched |
| **Multi-unit requests** | Surface top N donors needed for `required_units > 1` |
