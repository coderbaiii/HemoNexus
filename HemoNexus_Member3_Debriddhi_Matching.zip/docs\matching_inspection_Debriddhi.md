# HemoNexus — Matching Algorithm Inspection Report
**Branch:** `Debriddhi` | **Reviewer:** Member 3 — Debriddhi Ghosh  
**Status:** ✅ 58/58 tests passing | Read-only inspection, no code modified

---

## 0. Branch & Repository State

```
Branch  : Debriddhi  (branched from feature/hemonexas-donor-matching)
Repo    : C:\Users\DEBSRIDDHI GHOSH\Documents\GitHub\HemoNexus
Git exe : GitHub Desktop — app-3.6.6
```

The matching engine lives entirely inside two packages:

| Package | Role |
|---|---|
| `matching/` | Pure algorithmic logic (no Flask dependency) |
| `backend/services/matching_service.py` | Thin bridge adapter for backward-compat imports |
| `routes/patient.py` → `GET /api/patient/blood-requests/<id>/matches` | HTTP entry point |

---

## 1. Pipeline Architecture — How It Flows

```
HTTP GET /api/patient/blood-requests/<id>/matches
         │
         ▼  routes/patient.py  →  find_matching_donors()
         │
         ▼  matching/matcher.py  →  run_matching_pipeline()
         │
         ├─ Step 1  filter_by_blood_group()             matching/filters.py
         ├─ Step 2  filter_by_active_status()           matching/filters.py
         ├─ Step 3  filter_by_verification_status()     matching/filters.py
         ├─ Step 4  filter_by_temporary_availability()  matching/filters.py
         ├─ Step 5  filter_by_availability_schedule()   matching/filters.py
         │              └── check_availability()        matching/availability.py
         ├─ Step 6  calculate_and_attach_distances()    matching/filters.py
         │              └── calculate_distance_km()     matching/distance.py
         ├─ Step 7  filter_by_patient_distance()        matching/filters.py
         ├─ Step 8  filter_by_donor_travel_limit()      matching/filters.py
         ├─ Step 9  apply_ranking()                     matching/ranking.py
         │              ├── rank_nearest()
         │              ├── rank_fastest()
         │              ├── rank_recently_verified()
         │              └── rank_best_match()  →  calculate_matching_score()
         └─ Step 10 Final sanitization + medical disclaimer
```

> **Design principle:** Steps 1–8 are **hard gates** — any donor that fails is permanently excluded. Steps 9–10 operate only on the survivors.

---

## 2. File-by-File Function Inventory

### 2.1 `matching/filters.py` — The Prune Engine

| Function | Lines | Responsibility |
|---|---|---|
| `parse_iso_datetime(dt_str)` | 13–24 | Parses ISO-8601 string → UTC `datetime`. Fallback to `now()` on failure. |
| `compute_lifecycle_status(next_verification_dt, current_dt, grace_days)` | 26–41 | Returns `ACTIVE / VERIFICATION_DUE / INACTIVE` based on how far past `next_verification_date` we are. |
| `filter_by_blood_group(candidates, required_blood_group)` | 43–52 | **Step 1.** Exact string match after `.strip().upper()`. Returns `[]` if `required_blood_group` is falsy. |
| `filter_by_active_status(candidates)` | 54–56 | **Step 2.** Keeps only donors where `profile_status == 'ACTIVE'`. |
| `filter_by_verification_status(candidates, current_dt, grace_days=30)` | 58–73 | **Step 3.** Skips donors with no `next_verification_date`. Calls `compute_lifecycle_status`; keeps only `ACTIVE`. |
| `filter_by_temporary_availability(candidates)` | 75–77 | **Step 4.** Keeps donors where `is_available not in (0, False, "0", "false")`. |
| `filter_by_availability_schedule(candidates, target_datetime)` | 79–104 | **Step 5.** Delegates to `check_availability()`; attaches `availability_score` and `availability_label` to passing donors. |
| `calculate_and_attach_distances(candidates, patient_lat, patient_lon)` | 106–122 | **Step 6.** Calls `calculate_distance_km()`; falls back to `12.0 km` when coordinates are missing. |
| `filter_by_patient_distance(candidates, max_patient_distance)` | 124–137 | **Step 7.** Keeps donors where `distance_km <= max_patient_distance`. Default = 25.0 km. |
| `filter_by_donor_travel_limit(candidates)` | 139–158 | **Step 8.** Keeps donors where `distance_km <= maximum_travel_distance`. Default = 15.0 km. Attaches `donor_max_travel`. |

---

### 2.2 `matching/availability.py` — Time-Window Engine

| Function | Lines | Responsibility |
|---|---|---|
| `parse_time_str(time_str)` | 8–21 | Parses `"HH:MM"` string → `datetime.time`. |
| `is_time_in_range(current_time, start_time, end_time)` | 23–42 | **Critical.** Handles midnight-crossing correctly: if `start == end` → always True; if `start < end` → normal range; if `start > end` → overnight crossing (OR logic). |
| `check_availability(availability_type, target_datetime, is_available, available_from, available_to)` | 44–113 | Master availability checker. Returns `(bool, float_score, str_label)`. Handles: `24_HOURS` (1.0), `DAY/DAYTIME` (0.9), `NIGHT/NIGHTTIME` (0.9), `8_HOURS` (0.85), custom window (0.85), fallback (0.7). |

**Concrete time windows:**

| Type | Start | End | Score |
|---|---|---|---|
| `24_HOURS` | — | — | 1.0 |
| `DAY` / `DAYTIME` | 08:00 | 18:00 | 0.9 |
| `NIGHT` / `NIGHTTIME` | 18:00 | 06:00 (next day) | 0.9 |
| `8_HOURS` / `STANDARD_SHIFT` | 09:00 | 17:00 | 0.85 |
| Custom | `available_from` | `available_to` | 0.85 |
| Unknown / fallback | — | — | 0.7 (always True) |

---

### 2.3 `matching/distance.py` — Haversine Engine

| Function | Lines | Responsibility |
|---|---|---|
| `calculate_distance_km(donor_lat, donor_lon, patient_lat, patient_lon)` | 8–54 | Standard Haversine formula. Earth radius = 6371.0 km. Guards: `None` inputs → `None`; out-of-range lat/lon → `None`; non-numeric → `None`. Returns km rounded to 2 d.p. |
| `estimate_travel_time_minutes(distance_km, average_speed_kmh=30.0)` | 56–74 | Simple `(distance / speed) × 60`. No traffic model. Default speed = 30 km/h (configurable via `Config.DEFAULT_AVERAGE_SPEED_KMH`). |

---

### 2.4 `matching/ranking.py` — Sort & Score Engine

| Function | Lines | Responsibility |
|---|---|---|
| `parse_iso_datetime(dt_str)` | 13–24 | Local copy (duplicated from `filters.py`). |
| `calculate_verification_recency_score(last_verified_str, now_dt, interval_days=180)` | 26–37 | Linear decay: 1.0 = verified today → 0.1 at 180 days. Formula: `score = 1.0 - (days_old/180 * 0.9)`. |
| `calculate_matching_score(donor, patient_max_dist, urgency, weights, now_dt)` | 39–87 | Composite score (0–100). Four weighted factors. Urgency multiplier on distance factor. |
| `rank_nearest(candidates)` | 89–94 | Sort by `distance_km` ascending. Assigns `rank` integer. |
| `rank_fastest(candidates, average_speed_kmh)` | 96–109 | Computes `estimated_travel_time` then sorts ascending. |
| `rank_recently_verified(candidates)` | 111–120 | Sort by `last_verified_date` descending. |
| `rank_best_match(candidates, patient_max_dist, urgency, weights, now_dt)` | 122–141 | Computes `matching_score` + `score_breakdown` for all, then sorts descending. |
| `apply_ranking(candidates, sorting_preference, patient_max_dist, urgency, average_speed_kmh)` | 143–182 | **Dispatcher.** Pre-attaches `estimated_travel_time` to all, then routes to the chosen rank function. All modes also compute `matching_score` for display. |

**Composite Score Formula:**

$$\text{Score} = \bigl(0.30 \times S_{\text{avail}}\bigr) + \bigl(0.30 \times S_{\text{dist}} \times U\bigr) + \bigl(0.20 \times S_{\text{fresh}}\bigr) + \bigl(0.20 \times S_{\text{prox}}\bigr)$$

Where:
- $S_{\text{avail}}$ = `availability_score` (0.7–1.0, set by `check_availability`)
- $S_{\text{dist}}$ = `1 - (distance / effective_max)`, clamped 0–1
- $S_{\text{fresh}}$ = verification recency score (0.1–1.0)
- $S_{\text{prox}}$ = same as $S_{\text{dist}}$ (proximity used twice — see edge cases §3)
- $U$ = urgency multiplier: `NORMAL`=1.0, `URGENT`=1.1, `CRITICAL`=1.2
- `effective_max = max(patient_max_dist, donor_max_travel, 1.0)`
- Final score scaled ×100, clamped to 0–100

---

### 2.5 `matching/matcher.py` — Pipeline Orchestrator

| Function | Lines | Responsibility |
|---|---|---|
| `run_matching_pipeline(request_data, candidate_donors, sorting_preference, now_dt)` | 52–161 | Executes steps 1–10 sequentially. Accepts raw dicts (no DB dependency — testable in isolation). Returns list of sanitized result dicts. |
| `find_matching_donors(blood_request_id, db, override_sort)` | 163–205 | Loads blood request + donor profiles from DB. Resolves contact history (`is_already_contacted`). Calls `run_matching_pipeline`. |

**Step 10 sanitized output fields per match:**

```python
{
    "rank", "donor_id", "user_id", "full_name", "blood_group",
    "approximate_distance_km", "distance_km",        # backward-compat alias
    "estimated_travel_time", "availability",
    "availability_label", "maximum_travel_distance",
    "profile_status", "last_verified_date", "next_verification_date",
    "match_score", "matching_score",                 # backward-compat alias
    "score_breakdown", "masked_location",
    "phone", "email", "contact_status",
    "is_already_contacted", "medical_disclaimer"
}
```

> **Privacy note:** `latitude`, `longitude`, and street-level `location` are intentionally omitted. Only `masked_location` (static text like `"Kolkata Region"`) is returned.

---

### 2.6 `backend/services/matching_service.py` — Bridge Adapter

Three re-exported symbols for test backward-compatibility:

```python
haversine_distance_km     →  calculate_distance_km()        (distance.py)
is_availability_satisfied →  check_availability() wrapper   (availability.py)
calculate_verification_recency_score                        (ranking.py)
find_matching_donors      →  find_matching_donors()          (matcher.py)
```

---

### 2.7 HTTP Entry Point — `routes/patient.py`

```
GET /api/patient/blood-requests/<request_id>/matches
    @role_required("patient", "admin")
    → find_matching_donors(request_id, db=conn, override_sort=sort_override)
    → returns JSON { success, request_id, required_blood_group, total_matches, matches[] }
```

Optional query param: `?sort=NEAREST|FASTEST|RECENTLY_VERIFIED|BEST_MATCH`

---

## 3. Missing Logic & Edge Cases Identified

> [!CAUTION] These are **review findings only**. No code has been modified.

### 3.1 Blood-Group Compatibility Matrix is Absent (Step 1)

**File:** `matching/filters.py` → `filter_by_blood_group()`, line 51–52  
**Current behaviour:** Only exact ABO/Rh string match. An O+ patient requesting O+ blood will **never** match an O- donor, even though O- is the universal red-cell donor and medically compatible.

**Missing cases per medical transfusion science:**
| Recipient | Can receive from |
|---|---|
| O+ | O+, O- |
| O- | O- only |
| A+ | A+, A-, O+, O- |
| A- | A-, O- |
| B+ | B+, B-, O+, O- |
| B- | B-, O- |
| AB+ | ALL groups (universal recipient) |
| AB- | AB-, A-, B-, O- |

**Risk:** In a CRITICAL shortage, compatible donors are silently excluded.

---

### 3.2 Donation Cooldown — No Filter Exists

**Missing entirely** from the pipeline.  
Medical guidelines require a minimum 56-day (8-week) waiting period between whole-blood donations. The `donation_records` table exists and stores `donation_date`, but no step checks whether a donor has donated recently.

**Effect:** A donor who donated 3 days ago will appear as a top-ranked match.  
**Table available:** `donation_records (donor_id, donation_date)`

---

### 3.3 `parse_iso_datetime` is Duplicated in Two Modules

**Files:** `matching/filters.py` (lines 13–24) AND `matching/ranking.py` (lines 13–24)  
Identical code. Any future bug fix must be applied in both places.  
**Fix:** Move to `matching/distance.py` or a new `matching/utils.py` and import from there.

---

### 3.4 Missing-Coordinate Fallback is a Silent Lie (Step 6)

**File:** `matching/filters.py` → `calculate_and_attach_distances()`, lines 114–117  
```python
if dist is None:
    dist = 12.0   # ← hardcoded fallback
```
If a donor has no GPS coordinates, they get a fabricated 12.0 km distance. This donor then competes with real candidates at 12 km — potentially outranking verified nearby donors. The fallback value is also completely arbitrary (why 12.0?).

**Better approaches:**
- Exclude donors with no coordinates (safer for medical context)
- Assign `float("inf")` so they always rank last
- Log the missing data and skip

---

### 3.5 `filter_by_verification_status` Silently Drops Donors with No `next_verification_date` (Step 3)

**File:** `matching/filters.py`, lines 66–68  
```python
next_due_str = d.get("next_verification_date")
if not next_due_str:
    continue  # silently excluded
```
A donor inserted without `next_verification_date` (e.g. via a migration or direct DB insert) is **silently excluded** with no log or error. Could incorrectly prune valid donors during data migrations.

---

### 3.6 Score Formula Uses `S_dist` Twice — `WEIGHT_PROXIMITY_FIT` is Redundant

**File:** `matching/ranking.py` → `calculate_matching_score()`, lines 72–77  
```python
raw_score = (
    (w_avail * s_avail) +
    (w_dist  * s_dist * urgency_multiplier) +   # ← s_dist (with urgency)
    (w_fresh * s_fresh) +
    (w_prox  * s_dist)                          # ← s_dist again (no urgency)
)
```
Both `WEIGHT_DISTANCE` (0.30) and `WEIGHT_PROXIMITY_FIT` (0.20) use `s_dist`. The total distance weight is effectively `0.30 × U + 0.20`, which means distance dominates 50% of the score when urgency is NORMAL, and 56% when CRITICAL. **There is no independent proximity-fit factor.**  
The `score_breakdown` also only reports three values, omitting `proximity_fit` entirely:
```python
breakdown = {
    "availability_score": ...,
    "distance_score": ...,
    "verification_freshness_score": ...
    # proximity_fit missing from breakdown!
}
```

---

### 3.7 `VERIFICATION_DUE` Donors are Excluded Even Within Grace Period (Step 3)

**File:** `matching/filters.py` → `filter_by_verification_status()`, lines 70–72  
```python
status = compute_lifecycle_status(next_dt, current_dt=now, grace_days=grace_days)
if status == "ACTIVE":
    valid.append(d)
```
Donors in `VERIFICATION_DUE` (within 30-day grace period) are excluded here.  
However, their `profile_status` column in the DB can still read `'ACTIVE'` until the admin sweep runs. This creates an **inconsistency**: a donor who is `ACTIVE` in the DB but `VERIFICATION_DUE` by real-time calculation is excluded, but one who hasn't been swept yet passes Step 2 (profile_status check). The real-time filter (Step 3) is stricter than the DB-state filter (Step 2).

**Unintended effect:** `VERIFICATION_DUE` donors within grace period are entirely invisible even though the system is supposed to allow them a grace window.

---

### 3.8 `filter_by_temporary_availability` and `filter_by_availability_schedule` are Partially Redundant (Steps 4 & 5)

**File:** `matching/filters.py` (Step 4) and `matching/availability.py` (Step 5)  
`check_availability()` in Step 5 already checks `is_available == 0` at line 66–67 and returns `(False, 0.0, "Temporarily Unavailable")`. So if Step 4 were removed, Step 5 would still exclude temporarily unavailable donors. Step 4 provides defence-in-depth but the duplication is undocumented.

---

### 3.9 `required_date_time` Defaults Silently to `now` If Missing (matcher.py)

**File:** `matching/matcher.py`, line 79  
```python
req_dt = parse_iso_datetime(request_data.get("required_date_time")) or now
```
If a blood request has no `required_date_time`, the schedule filter uses the current moment. This is a reasonable default but means that DAYTIME and NIGHTTIME donors will match or not match based on **when the search is run**, not when the blood is needed. For pre-scheduled surgeries, this is incorrect.

---

### 3.10 No Maximum Result Limit (Unbounded Return)

**File:** `matching/matcher.py` → `run_matching_pipeline()`, line 132  
The pipeline returns **all passing candidates** with no upper bound. For a busy metro area with hundreds of donors, the API response could become very large. No `LIMIT` or pagination exists.

---

### 3.11 Distance Calculation — No Timezone Normalisation for `req_dt`

**File:** `matching/filters.py` → `filter_by_availability_schedule()` (Step 5)  
The schedule check uses `target_dt.time()` (UTC), but donors may think in local time (IST = UTC+5:30). A donor who sets `DAYTIME = 08:00–18:00` likely means 8 AM IST, not 8 AM UTC. There is no timezone conversion — the entire system implicitly assumes UTC throughout, which is correct only if all UIs also input times in UTC.

---

## 4. Summary Table of Findings

| # | Severity | Finding | File | Lines |
|---|---|---|---|---|
| 3.1 | 🔴 High | Blood-group compatibility matrix missing | `filters.py` | 51–52 |
| 3.2 | 🔴 High | Donation cooldown (56-day) not enforced | — | Missing |
| 3.3 | 🟡 Medium | `parse_iso_datetime` duplicated | `filters.py`, `ranking.py` | 13–24 |
| 3.4 | 🟡 Medium | Missing-coord fallback: hardcoded 12.0 km | `filters.py` | 114–117 |
| 3.5 | 🟡 Medium | No-`next_verification_date` silently drops donor | `filters.py` | 66–68 |
| 3.6 | 🟡 Medium | `s_dist` used twice; breakdown missing prox_fit | `ranking.py` | 72–85 |
| 3.7 | 🟡 Medium | VERIFICATION_DUE grace window not surfaced | `filters.py` | 70–72 |
| 3.8 | 🟢 Low | Steps 4 & 5 partially redundant (is_available) | `filters.py`, `availability.py` | — |
| 3.9 | 🟢 Low | `required_date_time` defaults to current time | `matcher.py` | 79 |
| 3.10 | 🟢 Low | Unbounded result count | `matcher.py` | 132 |
| 3.11 | 🟢 Low | No timezone conversion for schedule matching | `filters.py` | 79–104 |

---

## 5. What Is Working Correctly

- ✅ Haversine formula mathematically correct (validated against Kolkata landmark distances)
- ✅ Midnight-crossing availability windows handled correctly by `is_time_in_range()`
- ✅ Step-early-exit pattern (`if not stepN: return []`) is efficient
- ✅ `now_dt` injection in pipeline makes all time-dependent logic fully unit-testable
- ✅ Privacy safeguards — exact GPS never exposed in API response
- ✅ `medical_disclaimer` on every result
- ✅ Duplicate donor-dispatch prevention via UNIQUE constraint on `(blood_request_id, donor_id)`
- ✅ All 58 automated test cases pass as of inspection date

---

*Branch: `Debriddhi` | Inspection completed 27 Sep 2026 | No code modified*
